package com.adso.menucontex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private var itemlist= arrayOf("item1","item2","item3")
    private var listView:ListView? =  null
    private var arrayAdapter:ArrayAdapter<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView=findViewById(R.id.context_list_view)
        arrayAdapter = ArrayAdapter(applicationContext,android.R.layout.simple_list_item_1,itemlist)
        listView?.adapter=arrayAdapter
        registerForContextMenu(listView)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        menuInflater.inflate(R.menu.main_menu,menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.menu_call->{
                Toast.makeText(applicationContext, "call menu", Toast.LENGTH_SHORT).show()
                return true
            }
        else-> return super.onContextItemSelected(item)

    }
        return when(item.itemId){
            R.id.menu_phone->{
                Toast.makeText(applicationContext, "call phone", Toast.LENGTH_SHORT).show()
                return true
            }
            else-> return super.onContextItemSelected(item)

        }
        return when(item.itemId){
            R.id.menu_menssage->{
                Toast.makeText(applicationContext, "menssage", Toast.LENGTH_SHORT).show()
                return true
            }
            else-> return super.onContextItemSelected(item)

        }


        }
    }